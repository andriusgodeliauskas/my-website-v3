<?php
/**
 * The header for our theme (Clean Transparent & Sticky)
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">

<?php wp_head(); ?>

<!-- Tailwind & Fonts -->
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">
<script>
    tailwind.config = {
        theme: {
            extend: {
                fontFamily: { sans: ['Inter', 'sans-serif'] },
                colors: {
                    brand: {
                        dark: '#0f172a',
                        primary: '#2563eb',
                        primaryHover: '#1d4ed8',
                    }
                }
            }
        }
    }
</script>
<style>
    body { font-family: 'Inter', sans-serif; color: #0f172a; overflow-x: hidden; }
    
    /* Navigation Styles */
    .site-header-clean {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        z-index: 9999;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        padding: 2rem 3rem; /* Initial large padding */
        background: transparent;
        border-bottom: 1px solid transparent;
    }
    
    /* Scrolled State (Added via JS) */
    .site-header-clean.scrolled {
        padding: 1rem 3rem; /* Smaller padding */
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(12px);
        border-bottom: 1px solid #f1f5f9;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.02);
    }

    #nnfy-header, .header-default, .header-area { display: none !important; }

    /* Menu Items */
    .clean-nav-ul { list-style: none; display: flex; gap: 3rem; margin: 0; padding: 0; }
    .clean-nav-ul li a { 
        text-decoration: none; 
        font-size: 0.75rem; 
        font-weight: 800; 
        color: #0f172a; 
        letter-spacing: 0.2em; 
        text-transform: uppercase;
        transition: color 0.3s ease;
    }
    .clean-nav-ul li a:hover { color: #2563eb; }

    /* Mobile */
    @media (max-width: 768px) {
        .site-header-clean { padding: 1.5rem; }
        .site-header-clean.scrolled { padding: 1rem 1.5rem; }
    }
</style>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">

    <!-- HEADER -->
    <header id="masthead" class="site-header-clean flex justify-between items-center">
        <!-- Logo -->
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="text-2xl font-black tracking-tighter text-brand-dark group">
            AG<span class="text-brand-primary group-hover:animate-pulse">.</span>
        </a>

        <!-- Desktop Nav -->
        <nav class="hidden md:flex items-center gap-10">
            <ul class="clean-nav-ul">
                <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
                <li><a href="<?php echo get_permalink( wc_get_page_id( 'shop' ) ); ?>">Projects</a></li>
                <li><a href="<?php echo esc_url( home_url( '/about' ) ); ?>">About</a></li>
                <li><a href="<?php echo esc_url( home_url( '/contact' ) ); ?>">Contact</a></li>
            </ul>
            
            <!-- Cart -->
            <a href="<?php echo wc_get_cart_url(); ?>" class="ml-4 p-3 bg-brand-dark text-white rounded-full hover:bg-brand-primary transition-all relative shadow-lg hover:-translate-y-1">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" /></svg>
                <?php if ( WC()->cart->get_cart_contents_count() > 0 ) : ?>
                    <span class="absolute -top-1 -right-1 bg-red-500 text-white text-[9px] font-bold rounded-full h-4 w-4 flex items-center justify-center border-2 border-brand-dark">
                        <?php echo WC()->cart->get_cart_contents_count(); ?>
                    </span>
                <?php endif; ?>
            </a>
        </nav>

        <!-- Mobile Toggle -->
        <button class="md:hidden p-2 text-brand-dark bg-white/50 backdrop-blur-sm rounded-lg" onclick="document.getElementById('mobile-menu').classList.toggle('hidden')">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" /></svg>
        </button>
    </header>

    <!-- Mobile Menu Overlay -->
    <div id="mobile-menu" class="hidden fixed inset-0 z-[90] bg-white pt-32 px-6 pb-10 overflow-y-auto">
        <button onclick="document.getElementById('mobile-menu').classList.add('hidden')" class="absolute top-8 right-6 p-2"><svg class="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg></button>
        <div class="flex flex-col gap-8 text-center">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="text-4xl font-black text-brand-dark">HOME</a>
            <a href="<?php echo get_permalink( wc_get_page_id( 'shop' ) ); ?>" class="text-4xl font-black text-brand-dark">PROJECTS</a>
            <a href="<?php echo esc_url( home_url( '/about' ) ); ?>" class="text-4xl font-black text-brand-dark">ABOUT</a>
            <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="text-4xl font-black text-brand-dark">CONTACT</a>
        </div>
    </div>

    <!-- Scroll Script -->
    <script>
        window.addEventListener('scroll', function() {
            const header = document.getElementById('masthead');
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    </script>

    <div id="content" class="site-content"> <!-- No padding-top here, handled by hero sections -->