<?php
/**
 * The template for displaying the footer
 */
?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer py-32 bg-white border-t border-slate-100 text-center">
		<div class="site-info max-w-7xl mx-auto px-6 space-y-10">
            <!-- Footer Logo -->
            <div class="text-5xl font-black text-brand-dark italic">AG<span class="text-brand-primary">.</span></div>
            
            <!-- Navigation Links -->
            <div class="flex flex-col md:flex-row justify-center gap-8 text-sm font-bold uppercase tracking-widest text-slate-500">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="hover:text-brand-primary transition-colors">Home</a>
                <a href="<?php echo get_permalink( wc_get_page_id( 'shop' ) ); ?>" class="hover:text-brand-primary transition-colors">Projects</a>
                <a href="<?php echo esc_url( home_url( '/about' ) ); ?>" class="hover:text-brand-primary transition-colors">About</a>
                <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="hover:text-brand-primary transition-colors">Contact</a>
            </div>

            <!-- Copyright -->
            <p class="text-slate-400 font-bold tracking-widest text-[10px] uppercase pt-8">
                &copy; <?php echo date('Y'); ?> Andrius G. Crafted with Excellence.
            </p>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>