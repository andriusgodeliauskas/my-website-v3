<?php
/**
 * Template Name: Landing Page (Full Width Light v3 - Final)
 */

get_header(); 
?>

<style>
    /* Reset & Base */
    body { background-color: #ffffff !important; color: #0f172a; margin: 0; padding: 0; overflow-x: hidden; }
    
    /* Animations */
    @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
    .animate-fade-in-up { animation: fadeIn 0.8s ease-out forwards; }

    /* Product Grid (Showcase Style) */
    .woocommerce ul.products {
        display: grid !important;
        grid-template-columns: repeat(1, minmax(0, 1fr)) !important;
        gap: 4rem !important; /* Larger gap for showcase */
        padding-bottom: 2rem !important;
    }
    @media (min-width: 768px) {
        .woocommerce ul.products { grid-template-columns: repeat(2, minmax(0, 1fr)) !important; }
    }
    
    .woocommerce ul.products li.product {
        background: #ffffff !important;
        border: 1px solid #f1f5f9 !important; /* Slate 100 */
        border-radius: 3rem !important; /* Huge rounded corners */
        padding: 0 !important; /* No padding on card itself */
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.02) !important;
        width: 100% !important;
        margin: 0 !important;
        float: none !important;
        transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1) !important;
        overflow: hidden !important;
        position: relative !important;
    }
    .woocommerce ul.products li.product:hover {
        transform: translateY(-5px);
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.15) !important;
        border-color: #e2e8f0 !important;
    }
    
    /* Image Container */
    .woocommerce ul.products li.product a img {
        width: 100% !important;
        height: 400px !important; /* Taller images */
        object-fit: cover !important;
        margin: 0 !important;
        border-radius: 0 !important;
        transition: transform 0.7s ease !important;
    }
    .woocommerce ul.products li.product:hover a img {
        transform: scale(1.05);
    }

    /* Content below image */
    .woocommerce ul.products li.product .product-meta-wrapper {
        padding: 2rem !important;
        background: #ffffff !important;
        text-align: left !important;
    }

    .woocommerce ul.products li.product h2 { 
        font-size: 1.75rem !important; 
        font-weight: 900 !important; 
        color: #0f172a !important;
        margin-bottom: 0.5rem !important;
        line-height: 1.1 !important;
    }
    
    .woocommerce ul.products li.product .price { 
        color: #2563eb !important; 
        font-weight: 800 !important;
        font-size: 1.25rem !important;
        display: block !important;
        margin-bottom: 0 !important;
    }
    
    .woocommerce ul.products li.product .button {
        display: none !important; /* Hide default button for cleaner look */
    }
</style>

<!-- HERO SECTION -->
<section class="relative min-h-screen flex items-center justify-center px-4 sm:px-6 overflow-hidden -mt-24">
    <div class="absolute inset-0 z-0">
        <img src="<?php echo get_template_directory_uri(); ?>/images/hero-bg-dark.png" class="w-full h-full object-cover object-center">
        <div class="absolute inset-0 bg-white/40 backdrop-blur-[1px]"></div>
    </div>
    <div class="relative z-10 container mx-auto text-center space-y-10 pt-20">
        <div class="space-y-4">
            <h2 class="text-[10px] sm:text-sm tracking-[0.5em] text-brand-primary uppercase font-black">Good ideas for everyone</h2>
            <h1 class="text-6xl sm:text-8xl lg:text-[10rem] font-black tracking-tighter text-brand-dark leading-[0.85]">ANDRIUS G</h1>
        </div>
        <div class="w-24 sm:w-40 h-2 bg-brand-primary mx-auto rounded-full shadow-lg shadow-blue-500/20"></div>
        <div class="space-y-6">
            <p class="text-lg sm:text-3xl text-slate-800 font-bold max-w-2xl mx-auto italic">"Hi, I'm Andrius."</p>
            <p class="text-sm sm:text-xl text-slate-700 max-w-3xl mx-auto font-medium px-4 leading-relaxed">Tech enthusiast creating IT solutions for children's education and development.</p>
        </div>
        
        <div class="pt-8 sm:pt-12">
            <a href="#work" class="inline-block px-12 py-5 bg-brand-primary text-white font-black rounded-2xl hover:scale-105 transition-all shadow-2xl shadow-blue-500/40 uppercase tracking-widest text-xs">View My Work</a>
        </div>
    </div>
    
    <!-- Scroll Indicator -->
    <div class="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce flex flex-col items-center gap-2">
        <span class="text-[10px] font-black uppercase tracking-[0.3em] text-slate-400">Scroll</span>
        <svg class="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"></path></svg>
    </div>
</section>

<!-- EXPERTISE SECTION -->
<section id="expertise" class="py-32 px-6 bg-white">
    <div class="max-w-7xl mx-auto">
        <div class="text-center mb-24">
            <h2 class="text-5xl font-black text-brand-dark mb-6 tracking-tight uppercase italic">My Expertise</h2>
            <div class="w-20 h-1.5 bg-brand-primary mx-auto rounded-full"></div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-12">
            <!-- Cards -->
            <div class="p-12 bg-slate-50 rounded-[3rem] border border-slate-100 hover:bg-white hover:shadow-2xl transition-all duration-500 text-center group">
                <div class="w-20 h-20 bg-white rounded-2xl flex items-center justify-center mx-auto mb-10 text-brand-primary shadow-sm group-hover:bg-brand-primary group-hover:text-white transition-all"><svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"></path></svg></div>
                <h3 class="text-2xl font-bold mb-4 text-brand-dark">Web Development</h3>
                <p class="text-slate-500 leading-relaxed">Responsive, high-performance websites built with modern technologies.</p>
            </div>
            <div class="p-12 bg-slate-50 rounded-[3rem] border border-slate-100 hover:bg-white hover:shadow-2xl transition-all duration-500 text-center group">
                <div class="w-20 h-20 bg-white rounded-2xl flex items-center justify-center mx-auto mb-10 text-brand-primary shadow-sm group-hover:bg-brand-primary group-hover:text-white transition-all"><svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg></div>
                <h3 class="text-2xl font-bold mb-4 text-brand-dark">Education Tech</h3>
                <p class="text-slate-500 leading-relaxed">Designing tools and platforms that empower children to learn effectively.</p>
            </div>
            <div class="p-12 bg-slate-50 rounded-[3rem] border border-slate-100 hover:bg-white hover:shadow-2xl transition-all duration-500 text-center group">
                <div class="w-20 h-20 bg-white rounded-2xl flex items-center justify-center mx-auto mb-10 text-brand-primary shadow-sm group-hover:bg-brand-primary group-hover:text-white transition-all"><svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg></div>
                <h3 class="text-2xl font-bold mb-4 text-brand-dark">UI/UX Design</h3>
                <p class="text-slate-500 leading-relaxed">Creating intuitive and visually stunning interfaces for all users.</p>
            </div>
        </div>
    </div>
</section>

<!-- PROJECTS SECTION -->
<section id="work" class="py-32 px-6 bg-slate-50">
    <div class="max-w-7xl mx-auto">
        <div class="text-center mb-24">
            <h2 class="text-5xl font-black text-brand-dark mb-6 tracking-tight uppercase italic">Selected Projects</h2>
            <div class="w-20 h-1.5 bg-brand-primary mx-auto rounded-full"></div>
        </div>
        
        <!-- WooCommerce Products Shortcode -->
        <div class="woocommerce-custom-wrapper">
            <?php 
            if ( shortcode_exists( 'products' ) ) {
                echo do_shortcode('[products limit="4" columns="2" orderby="date" order="DESC"]'); 
            } else {
                echo '<p class="text-center text-slate-400">Products will appear here.</p>';
            }
            ?>
        </div>
        
        <div class="text-center mt-20">
            <a href="<?php echo get_permalink( wc_get_page_id( 'shop' ) ); ?>" class="px-12 py-5 border-2 border-brand-dark text-brand-dark font-bold rounded-full hover:bg-brand-dark hover:text-white transition-all uppercase tracking-widest text-xs">View All Projects</a>
        </div>
    </div>
</section>

<!-- CONTACT SECTION -->
<section id="contact" class="py-32 px-6 bg-white">
    <div class="max-w-5xl mx-auto bg-brand-dark rounded-[4rem] shadow-2xl overflow-hidden flex flex-col md:flex-row">
        <div class="p-16 md:w-1/2 text-white space-y-12">
            <h3 class="text-6xl font-black leading-tight tracking-tighter">Let's work <br><span class="text-brand-primary">together</span>.</h3>
            <div class="space-y-6">
                <a href="mailto:andrius.godeliauskas@gmail.com" class="flex items-center gap-4 text-slate-300 hover:text-white transition-colors">
                    <svg class="w-6 h-6 text-brand-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                    <span class="text-xl">andrius.godeliauskas@gmail.com</span>
                </a>
                <a href="tel:+37060127050" class="flex items-center gap-4 text-slate-300 hover:text-white transition-colors">
                    <svg class="w-6 h-6 text-brand-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                    <span class="text-xl font-bold">+370 601 27050</span>
                </a>
            </div>
        </div>
        <div class="md:w-1/2 bg-slate-100 flex items-center justify-center p-16">
            <div class="text-center space-y-6">
                <div class="w-24 h-24 bg-white rounded-full flex items-center justify-center mx-auto shadow-xl text-brand-primary"><svg class="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path></svg></div>
                <p class="text-brand-dark font-black text-xl italic uppercase tracking-tighter">Response in 24 hours.</p>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>