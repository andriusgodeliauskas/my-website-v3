<?php
/**
 * Andrius G Theme functions and definitions
 */

if ( ! function_exists( 'andrius_g_setup' ) ) :
	function andrius_g_setup() {
		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		// Let WordPress manage the document title.
		add_theme_support( 'title-tag' );

		// Enable support for Post Thumbnails on posts and pages.
		add_theme_support( 'post-thumbnails' );

		// Register Navigation Menus
		register_nav_menus( array(
			'primary' => esc_html__( 'Primary Menu', 'andrius-g-theme' ),
		) );

		// HTML5 support
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

        // WooCommerce Support
        add_theme_support( 'woocommerce' );
        add_theme_support( 'wc-product-gallery-zoom' );
        add_theme_support( 'wc-product-gallery-lightbox' );
        add_theme_support( 'wc-product-gallery-slider' );
	}
endif;
add_action( 'after_setup_theme', 'andrius_g_setup' );

/**
 * Enqueue scripts and styles.
 */
function andrius_g_scripts() {
	wp_enqueue_style( 'andrius-g-style', get_stylesheet_uri() );
    // Tailwind is loaded via CDN in header.php for simplicity in this version
}
add_action( 'wp_enqueue_scripts', 'andrius_g_scripts' );
